/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-E10
 */

#ifndef myBoard_VIRTNC__
#define myBoard_VIRTNC__



#endif /* myBoard_VIRTNC__ */ 
